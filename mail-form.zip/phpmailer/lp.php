<?php
$l_one = 'mt';
$l_two = 'web-vluki.ru';

$p_one = 'zemnb';
$p_two = 'jnip';
?>